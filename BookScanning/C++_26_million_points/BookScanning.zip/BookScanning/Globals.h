#pragma once

uint32_t g_numDaysLeft = 0;
std::vector<uint32_t> g_bookScores;